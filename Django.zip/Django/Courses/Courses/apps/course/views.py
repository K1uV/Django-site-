from django.http import Http404, HttpResponseRedirect
from django.shortcuts import render
from .models import Course
from django.urls import reverse

def index(request):
    latest_courses_list = Course.objects.order_by('-date_of_start')[:5]
    return render(request, 'courses\list.html', {'latest_courses_list' : latest_courses_list})
    
def detail(request, course_id):
    try:  
        a = Course.objects.get( id = course_id)
    except:
        raise Http404("Курс не найден!")
    latest_comments_list = a.comment_set.order_by('-id')[:10]
    return render(request, 'courses/detail.html', {'course' : a, 'latest_comments_list': latest_comments_list})

def leave_comment(request, course_id):
    try:
        a = Course.objects.get( id = course_id)
    except:
        raise Http404("Курс не найден!")

    a.comment_set.create(author_name = request.POST['name'], comment_text = request.POST['text'])
    return HttpResponseRedirect( reverse('courses:detail', args = (a.id,)))
