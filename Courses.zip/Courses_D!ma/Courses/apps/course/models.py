import datetime
from django.db import models
from django.utils import timezone

class Course(models.Model):
    course_title = models.CharField('Name of course', max_length = 200)
    course_description = models.TextField("Descriptiom of cource")
    date_of_start = models.DateTimeField('Date of begining of course')

    def __str__(self):
        return self.course_title

    def Meta():
        verbose_name = "Course"
        verbose_name_plural = "Courses"

class Comment(models.Model):
    course = models.ForeignKey(Course, on_delete = models.CASCADE)
    author_name = models.CharField('Name of author', max_length = 30)
    comment_text = models.CharField('Text of comment', max_length = 200)

    def __str__(self):
        return self.author_name

    def Meta():
        verbose_name = "Comment"
        verbose_name_plural = "Comments"
